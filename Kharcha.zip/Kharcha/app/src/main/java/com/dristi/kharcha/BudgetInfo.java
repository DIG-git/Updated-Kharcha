package com.dristi.kharcha;

public class BudgetInfo {
    public int id;
    public String fromdate;
    public int amount;
    public String category;
    public String todate;
}
