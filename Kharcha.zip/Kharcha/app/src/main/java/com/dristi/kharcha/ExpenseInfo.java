package com.dristi.kharcha;

public class ExpenseInfo {

    public String date;
    public String category;
    public String description;
    public int id;
    public int amount;
    public String cashcredit;
    //public int amount;
}
