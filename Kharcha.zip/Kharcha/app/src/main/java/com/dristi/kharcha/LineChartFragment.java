package com.dristi.kharcha;

import android.app.Fragment;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.view.LineChartView;

public class LineChartFragment extends android.support.v4.app.Fragment {

    LineChartView houselinechart, eatinglinechart, personallinechart, grocerylinechart;
    LineChartView utilitieslinechart, medicallinechart, eduationlinechart;

    String date;

    DatabaseHelper databaseHelper;

    SharedPreferences preferences;

    int set;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.line_chart,null);

        houselinechart = view.findViewById(R.id.housechart);
        eatinglinechart = view.findViewById(R.id.eatingchart);
        grocerylinechart = view.findViewById(R.id.grocerychart);
        personallinechart = view.findViewById(R.id.personalchart);
        utilitieslinechart = view.findViewById(R.id.utilitieschart);
        medicallinechart = view.findViewById(R.id.medicalchart);
        eduationlinechart = view.findViewById(R.id.educationchart);

        set = 0;

        databaseHelper = new DatabaseHelper(getActivity());

        preferences = getActivity().getSharedPreferences("Date",0);

//        if(set == 0){
//            setDate(preferences.getString("Date",""));
//            set++;
//        }

        makechart("Household");
        makechart("Eating-out");
        makechart("Grocery");
        makechart("Personal");
        makechart("Utilities");
        makechart("Medical");
        makechart("Education");

        return view;
    }

    public void makechart(String category){

        setDate("2019-07-01");

        String[] axisData = {"1" , "2", "3" , "4" , "5" };
        int[] yAxisData =  new int[5];

        for(int i=0; i<5; i++){

            yAxisData[i] = databaseHelper.getlinecategorytotal(category, getDate());
            setDate(getnewdate(getDate()));
        }

        List yAxisValues = new ArrayList();
        List axisValues = new ArrayList();

        Line line = new Line(yAxisValues).setColor(Color.parseColor("#FFF46E72"));

        for(int i = 0; i<axisData.length;i++){
            axisValues.add(i,new AxisValue(i).setLabel(axisData[i]));
        }

        for(int i = 0; i<yAxisData.length;i++){
            yAxisValues.add(new PointValue(i,yAxisData[i]));
        }

        List lines = new ArrayList();
        lines.add(line);

        LineChartData data = new LineChartData();
        data.setLines(lines);

        switch (category){
            case "Household":
                houselinechart.setLineChartData(data);
                break;

            case "Eating-out":
                eatinglinechart.setLineChartData(data);
                break;

            case "Personal":
                personallinechart.setLineChartData(data);
                break;

            case "Grocery":
                grocerylinechart.setLineChartData(data);
                break;

            case "Utilities":
                utilitieslinechart.setLineChartData(data);
                break;

            case "Medical":
                medicallinechart.setLineChartData(data);
                break;

            case "Education":
                eduationlinechart.setLineChartData(data);
                break;

                default:
                    break;
        }

        Axis axis = new Axis();
        axis.setValues(axisValues);
        data.setAxisXBottom(axis);

        Axis yAxis = new Axis();
        data.setAxisYLeft(yAxis);

        axis.setTextSize(12);
        axis.setTextColor(Color.BLACK);

        yAxis.setTextColor(Color.BLACK);
        yAxis.setTextSize(12);

        axis.setName("Weeks");
        yAxis.setName("Expenses");

    }

    public String getnewdate(String date){

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();

        try{
            calendar.setTime(df.parse(date));
        }
        catch (ParseException e){
            e.printStackTrace();
        }

        calendar.add(Calendar.DATE,7);
        String newdate = df.format(calendar.getTime());
        return newdate;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String datevalue){
        date = datevalue;
    }
}
