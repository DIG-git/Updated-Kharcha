package com.dristi.kharcha;

public class Userinfo {

    public String id,username,password,confirmpass,email,gender;
}
